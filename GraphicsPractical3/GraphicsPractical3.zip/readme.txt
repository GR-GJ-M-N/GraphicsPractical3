a
Gert-Jan van Ginkel		5490723
Mehul Mistry			4255704
Norico Groeneveld		4301358

b
E2 try	Mehul
E3		Gert-Jan
E5		Norico
E6		Norico
M5		Gert-jan en Mehul

c
E5	https://digitalerr0r.wordpress.com/2009/04/22/xna-shader-programming-tutorial-9-post-process-wiggle/
E6	same as E5 and the demo on http://www.dhpoware.com/demos/xnaGaussianBlur.html#_blank

d
E3, E5 and E6 work
E2 didn't work, partially because of some software issues, and is thus not included
M5 kind of works a bit

We implemented the effects in Effect1.fx and moved part of the code from each task to Scene.cs to make the switching possible and the whole code less of a mess
Besides cycling through the tasks, you can move the camera with W and S, rotate the object with A and D and move the object by moving the mouse